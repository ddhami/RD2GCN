import numpy as np
from scipy.spatial import distance
from sklearn.metrics.pairwise import manhattan_distances, euclidean_distances
from os.path import join, exists, abspath, split
import time

def load_features(p, ds):
    content = np.genfromtxt(join(p, '{}.content'.format(ds)), dtype = np.dtype(str)) 
    idx_features_labels = np.array([l.split(',') for l in content])
    fts = np.array(idx_features_labels[:, 1:-1], dtype=np.dtype(float))
    return fts

def cal_linf_dis(fts):
    linf_dis = [[distance.chebyshev(ft, f) for f in fts] for ft in fts]
    linf_dis = np.array(linf_dis, dtype = np.dtype(float))
    return linf_dis

def cal_l1_dis(fts):
    return manhattan_distances(fts, fts)

def cal_l2_dis(fts):
    return euclidean_distances(fts, fts)

def dis_to_adj(dis):
    num = dis.shape[0]
    # normalize
    avg = dis.sum() / (num * num - num)
    # assume distance always non-negative
    # if avg = 0, set it to 1, nothing to divide
    if avg == 0:
        avg = 1.0
    dis = dis / avg
    dis[dis > 1] = 1
    # calculate adj
    adj = 1 - dis
    return adj
    

# settings
start_time = time.time()

print('Loading features')

dataset = 'icml'
path = join('data/ROC-features/LP', dataset)
path_linf = join(path, dataset + '_linf.adj')
path_l1 = join(path, dataset + '_l1.adj')
path_l2 = join(path, dataset + '.adj')
flag_linf = False
flag_l1 = False
flag_l2 = True

features = load_features(path, dataset)

if flag_linf:
    print('Generating L-inf adj')
    dis_linf = cal_linf_dis(features)
    adj_linf = dis_to_adj(dis_linf)
    np.savetxt(path_linf, adj_linf, delimiter = ',')

    print('L-inf time usage: %.2f seconds' % (time.time() - start_time))
    del dis_linf, adj_linf
    start_time = time.time()

if flag_l1:
    print('Generating L-1 adj', flush = True)
    dis_l1 = cal_l1_dis(features)
    adj_l1 = dis_to_adj(dis_l1)
    np.savetxt(path_l1, adj_l1, delimiter = ',')

    print('L-1 time usage: %.2f seconds' % (time.time() - start_time))
    del dis_l1, adj_l1
    start_time = time.time()

if flag_l2:
    print('Generating L-2 adj')
    dis_l2 = cal_l2_dis(features)
    adj_l2 = dis_to_adj(dis_l2)
    np.savetxt(path_l2, adj_l2, delimiter = ',')

    print('L-2 time usage: %.2f seconds' % (time.time() - start_time))

