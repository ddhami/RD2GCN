import torch.nn as nn
import torch.nn.functional as F
from pygcn.layers import GraphConvolution


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout
        
        # my test
        #print('#GCN: 3')
        #self.gc1 = GraphConvolution(nfeat, nhid)
        #self.gc2 = GraphConvolution(nhid, nhid)
        #self.gc3 = GraphConvolution(nhid, nclass)
        #self.dropout = dropout
        
        # my test
        #print('#GCN: 4')
        #self.gc1 = GraphConvolution(nfeat, nhid)
        #self.gc2 = GraphConvolution(nhid, nhid)
        #self.gc3 = GraphConvolution(nhid, nhid)
        #self.gc4 = GraphConvolution(nhid, nclass)
        #self.dropout = dropout
        
        # my test
        #print('#GCN: 5')
        #self.gc1 = GraphConvolution(nfeat, nhid)
        #self.gc2 = GraphConvolution(nhid, nhid)
        #self.gc3 = GraphConvolution(nhid, nhid)
        #self.gc4 = GraphConvolution(nhid, nhid)
        #self.gc5 = GraphConvolution(nhid, nclass)
        #self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return F.log_softmax(x, dim=1)

        # my test
        #x = F.relu(self.gc1(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = F.relu(self.gc2(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = self.gc3(x, adj)
        #return F.log_softmax(x, dim=1)
        
        # my test
        #x = F.relu(self.gc1(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = F.relu(self.gc2(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = F.relu(self.gc3(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training) 
        #x = self.gc4(x, adj)
        #return F.log_softmax(x, dim=1)
        
        # my test
        #x = F.relu(self.gc1(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = F.relu(self.gc2(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training)
        #x = F.relu(self.gc3(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training) 
        #x = F.relu(self.gc4(x, adj))
        #x = F.dropout(x, self.dropout, training=self.training) 
        #x = self.gc5(x, adj)
        #return F.log_softmax(x, dim=1)
