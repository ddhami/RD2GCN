from setuptools import setup
from setuptools import find_packages

setup(name='pygcn',
      install_requires=['numpy',
                        'torch',
                        'scipy'
                        ])
