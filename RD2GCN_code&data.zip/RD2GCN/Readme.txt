The data folder includes ROC-features and PRA-features of all datasets we used.
Step 1, use generate_distance_matrix.py to create distance matrix from data features.
Step 2, put the data (ex. icml.content, icml.adj) under the data folder in pygcn, which contains the GCN code.
Step 3, modify the load_data function in utils.py to load the designated dataset.
Step 4, run `python setup.py install`.
Step 5, run GCN model by `python train.py`.
Step 6, after the GCN finishes, collect all results files to the same folder of evaluation.py. And execute `python evaluation.py` to get the performance evaluation.

