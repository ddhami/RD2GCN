import numpy as np
import sklearn.metrics as M

dataset = 'icml'

output_path = './' + dataset + '/class_output.txt'
labels_path = './' + dataset + '/class_label.txt'
idx_train_path = './' + dataset + '/idx_train.txt'
idx_val_path = './' + dataset + '/idx_val.txt'
idx_test_path = './' + dataset + '/idx_test.txt'

outputs = np.genfromtxt(output_path, dtype = np.dtype(str))
labels = np.genfromtxt(labels_path, dtype = np.dtype(str))
idx_train = np.genfromtxt(idx_train_path, dtype = np.dtype(str))
idx_val = np.genfromtxt(idx_val_path, dtype = np.dtype(str))
idx_test = np.genfromtxt(idx_test_path, dtype = np.dtype(str))

# read labels and predictions
outputs = np.array(outputs, dtype = np.float32)
labels = np.array(labels, dtype = np.float32)
# read indices of train, validation and test
idx_train = np.array(np.array(idx_train, dtype = np.float32), dtype = np.int)
idx_val = np.array(np.array(idx_val, dtype = np.float32), dtype = np.int)
idx_test = np.array(np.array(idx_test, dtype = np.float32), dtype = np.int)

outputs = outputs[idx_test, :]
labels = labels[idx_test]

#pred_labels = np.argmax(outputs, axis = 1)
# try to favor the label 1 because 
# if there is a tie, np.argmax always picks the first one
# this won't influence much for most of the case, there is not much a tie
temp_outputs = np.stack((outputs[:, 1], outputs[:, 0]), axis = 1)
pred_labels = 1 - np.argmax(temp_outputs, axis = 1)

print('The number of examples in test: %d' % labels.shape[0])

print('The number of pos (true): %d' % labels.sum())
print('The number of neg (true): %d' % (labels.shape[0] - labels.sum()))
print('The number of pos (pred): %d' % pred_labels.sum())
print('The number of neg (pred): %d' % (pred_labels.shape[0] - pred_labels.sum()))

# since the output is log_softmax, exp turns it to probability
# after we solve the order uncertainty issue of GCN code,
# then outputs[:, 1] should be the scores of label 1
pred_scores = np.exp(outputs[:, 1])

c_precisions, c_recalls, c_thresholds = M.precision_recall_curve(labels, pred_scores)
c_precision = M.precision_score(labels, pred_labels)
c_recall = M.recall_score(labels, pred_labels)
c_f1 = M.f1_score(labels, pred_labels)
c_auc = M.auc(c_recalls, c_precisions)
c_accuracy = M.accuracy_score(labels, pred_labels)

print("Recall: %.3f" % c_recall)
print("Precision: %.3f" % c_precision)
print("F1: %.3f" % c_f1)
print("AUC-PR: %.3f" % c_auc)
print("Accuracy: %.3f" % c_accuracy)

